package com.example.currencyconverter;

public class ExchangeRateUpdateRunnable implements Runnable{
    @Override
    public void run() {

    }
}
